package co.javatech.bookrev;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookReviewAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
